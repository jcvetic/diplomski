import cv2 as cv
width = 800 ; height = 600; framerate = "30/1"; numcam = 3

cam1 = ( 
    "v4l2src device=/dev/video0 ! "
    "image/jpeg, width={}, height={}, framerate={} ! " 
    "jpegdec ! videoconvert ! videobalance brightness=0.01 contrast=0.89 saturation=1.34 ! appsink" # 0.01 0.89 1.33
    ).format(width, height, framerate)

cam2 = (
    "v4l2src device=/dev/video1 ! "
    "image/jpeg, width={}, height={}, framerate={} ! "
    "jpegdec ! videoconvert ! videobalance brightness=-0.01 contrast=0.87 saturation=1.35 ! appsink" # -0.02
    ).format(width,height,framerate)

cam3 = (
    "v4l2src device=/dev/video2 ! "
    "image/jpeg, width={}, height={}, framerate={} ! "
    "jpegdec ! videoconvert ! videobalance brightness=0.01 contrast=0.87 saturation=1.35 ! appsink"
    ).format(width,height,framerate)

camlist = [cam1,cam2,cam3]
for cam in range(len(camlist)):
    current_cam = camlist[cam]

    cap = cv.VideoCapture(current_cam,cv.CAP_GSTREAMER)
    num = 0

    while cap.isOpened():
        succes, img = cap.read()
        k = cv.waitKey(5)
        if k == 27 or num == 10:
            break
        elif k == ord('s'): # wait for 's' key to save and exit
            cv.imwrite('/home/fsb/Desktop/diplomski_opencv/intrinsic_calibration/images_dev{}/img{}.png'.format(cam,num), img)
            print("image{} saved!".format(num))
            num += 1
        cv.imshow('Img',img)
            
    # Release and destroy all windows before termination
    cap.release()
    cv.destroyAllWindows()