# import Tkinter as tk #type: ignore
# import cv2 as cv
# import subprocess, pickle
# from tip_recognize import extractdart, findpoint, getscore
# from frames import Scenechange
# from multiprocessing import Process, Manager
# from threading import Thread

# def process_camera(cam, cammatrix, warpmatrix, flagnum, scorelist):
#     runcam = Scenechange(cam)
    
#     while True:
#         try:
#             nodart, dart = runcam.detect_scene_change()
#             img, nodart, dart, boxmask, contlist, thresh = extractdart(nodart, dart, cammatrix)
#             point, nodart = findpoint(img, nodart, dart, boxmask, contlist, warpmatrix,flagnum, thresh)
#             score = getscore(point, nodart, flagnum)
#         except IndexError:
#             print("Dart contour is incomplete - score set to zero.")
#             score = 0
#             cv.destroyAllWindows()
#         except TypeError:
#             print("Can't find the impact point - score set to zero.")
#             score = 0
#             cv.destroyAllWindows() # nadodaj ValueError - bigcont = max(---)
#         # print(score)
#         scorelist.append(score)

# def update_gui(entry1, entry2, entry3, entry_total, scorelist):
#     entrylist = [entry1, entry2, entry3]
#     numen = 0
#     total_score = 0
#     while True:
#         if len(scorelist) == 3:
#             print(scorelist)
#             score = max(set(scorelist), key=scorelist.count)
#             print(score)
#             scorelist[:] = []
#             entrylist[numen].delete(0, tk.END)
#             entrylist[numen].insert(0, str(score))
            
#             total_score += score

#             numen += 1
            
#             if numen == 3:
#                 entry_total.delete(0, tk.END)
#                 entry_total.insert(0, str(total_score))
#                 total_score = 0
#                 numen = 0
                
# def main():    
#     manager = Manager()
#     scorelist = manager.list()    
#     width = 800
#     height = 600
#     framerate = "10/1"
    
#     # Initialize cameras
#     subprocess.call(["v4l2-ctl", "-d","/dev/video0", "--set-ctrl=exposure_auto=1"])
#     subprocess.call(["v4l2-ctl", "-d","/dev/video0", "--set-ctrl=exposure_absolute=31"])
#     subprocess.call(["v4l2-ctl", "-d", "/dev/video0", "--set-ctrl=gamma=112"])
#     subprocess.call(["v4l2-ctl", "-d", "/dev/video0", "--set-ctrl=sharpness=4"])

#     subprocess.call(["v4l2-ctl", "-d","/dev/video1", "--set-ctrl=exposure_auto=1"])
#     subprocess.call(["v4l2-ctl", "-d","/dev/video1", "--set-ctrl=exposure_absolute=29"])
#     subprocess.call(["v4l2-ctl", "-d", "/dev/video1", "--set-ctrl=gamma=112"])
#     subprocess.call(["v4l2-ctl", "-d", "/dev/video1", "--set-ctrl=sharpness=4"])

#     subprocess.call(["v4l2-ctl", "-d","/dev/video2", "--set-ctrl=exposure_auto=1"])
#     subprocess.call(["v4l2-ctl", "-d","/dev/video2", "--set-ctrl=exposure_absolute=30"])
#     subprocess.call(["v4l2-ctl", "-d", "/dev/video2", "--set-ctrl=gamma=112"])
#     subprocess.call(["v4l2-ctl", "-d", "/dev/video2", "--set-ctrl=sharpness=4"])

#     cam1 = ( 
#         "v4l2src device=/dev/video0 ! "
#         "image/jpeg, width={}, height={}, framerate={} ! " 
#         "jpegdec ! videoconvert ! videobalance brightness=0.01 contrast=0.89 saturation=1.34 ! appsink drop=1"
#         ).format(width, height, framerate)

#     cam2 = (
#         "v4l2src device=/dev/video1 ! "
#         "image/jpeg, width={}, height={}, framerate={} ! "
#         "jpegdec ! videoconvert ! videobalance brightness=-0.01 contrast=0.87 saturation=1.35 ! appsink drop=1"
#         ).format(width, height, framerate)

#     cam3 = (
#         "v4l2src device=/dev/video2 ! "
#         "image/jpeg, width={}, height={}, framerate={} ! "
#         "jpegdec ! videoconvert ! videobalance brightness=0.01 contrast=0.87 saturation=1.35 ! appsink drop=1"
#         ).format(width, height, framerate)

#     camlist = [cam1, cam2, cam3]
#     processes = []; cammatrices = []; warpmatrices = []; flag = []

#     for num in range(0,3):
#         file = open ("/home/fsb/Desktop/diplomski_opencv/intrinsic_calibration/calibration_cam{}.pkl".format(num), "rb") 
#         cammatrix = pickle.load(file)
#         file.close()
#         cammatrices.append(cammatrix)
        
#         file = open("/home/fsb/Desktop/diplomski_opencv/tkinter/matrixwarp{}.pkl".format(num), "rb")
#         warp = pickle.load(file)
#         file.close()
#         warpmatrices.append(warp)
        
#         flag.append(num)

#     for cam, matrix, warpmatrix, flagnum in zip (camlist, cammatrices, warpmatrices, flag):
#         p = Process(target=process_camera, args=(cam, matrix, warpmatrix, flagnum, scorelist,))
#         p.daemon = True
#         p.start()
#         processes.append(p)
            
#     root = tk.Tk()
#     root.title("Darts Scoring")

#     entry1 = tk.Entry(root, width=5, bg="gray65", bd=3, justify="center", font=("Arial", 14))
#     entry1.place(x=50, y=250)
#     entry2 = tk.Entry(root, width=5, bg="gray65", bd=3, justify="center", font=("Arial", 14))
#     entry2.place(x=150, y=250)
#     entry3 = tk.Entry(root, width=5, bg="gray65", bd=3, justify="center", font=("Arial", 14))
#     entry3.place(x=250, y=250)

#     entry_total = tk.Entry(root, width=10, bg="gray65", bd=3, justify="center", font=("Arial", 14))
#     entry_total.place(x=350, y=250)

#     gui_thread = Thread(target=update_gui, args=(entry1, entry2, entry3, entry_total, scorelist))
#     gui_thread.daemon = True
#     gui_thread.start()

#     root.mainloop()

################## # # # # # # # # # # # # -- dobar kod
import Tkinter as tk #type: ignore
import cv2 as cv
import subprocess, pickle
from tip_recognize import extractdart, findpoint, getscore
from frames import Scenechange
from multiprocessing import Process, Manager
from threading import Thread

def updatescore(entry1, entry2, entry3, entry_total):
    try:
        total_score = int(entry1.get()) + int(entry2.get()) + int(entry3.get())
        entry_total.delete(0, tk.END)
        entry_total.insert(0, str(total_score))
    except ValueError:
        pass
    
def process_camera(cam, cammatrix, warpmatrix, flagnum, scorelist):
    runcam = Scenechange(cam)
    
    while True:
        try:
            nodart, dart = runcam.detect_scene_change()
            img, nodart, dart, boxmask, contlist, thresh = extractdart(nodart, dart, cammatrix)
            point, nodart = findpoint(img, nodart, dart, boxmask, contlist, warpmatrix,flagnum, thresh)
            score = getscore(point, nodart, flagnum)
        except IndexError:
            print("Dart contour is incomplete - score set to zero.")
            score = 0
            cv.destroyAllWindows()
        except TypeError:
            print("Can't find the impact point - score set to zero.")
            score = 0
            cv.destroyAllWindows() # nadodaj ValueError - bigcont = max(---)
        except:
            print("Something else is wrong.")
            score = 0
        # print(score)
        scorelist.append(score)

def update_gui(entry1, entry2, entry3, entry_total, scorelist):
    entrylist = [entry1, entry2, entry3]
    numen = 0
    total_score = 0
    while True:
        if len(scorelist) == 3:
            print(scorelist)
            score = max(set(scorelist), key=scorelist.count)
            print(score)
            scorelist[:] = []
            entrylist[numen].delete(0, tk.END)
            entrylist[numen].insert(0, str(score))
            
            total_score += score

            numen += 1
            
            if numen == 3:
                entry_total.delete(0, tk.END)
                entry_total.insert(0, str(total_score))
                total_score = 0
                numen = 0
                
def main():    
    manager = Manager()
    scorelist = manager.list()    
    width = 800
    height = 600
    framerate = "15/1"
    
    # Initialize cameras
    subprocess.call(["v4l2-ctl", "-d","/dev/video0", "--set-ctrl=exposure_auto=1"])
    subprocess.call(["v4l2-ctl", "-d","/dev/video0", "--set-ctrl=exposure_absolute=26"]) # 34 -- Mijenjaj EKSPOZICIJU OVISNO O VANJSKOM SVJETLU - CILJ IMATI INFO O STRELICI!!!!!!!!!!
    subprocess.call(["v4l2-ctl", "-d", "/dev/video0", "--set-ctrl=gamma=112"])
    subprocess.call(["v4l2-ctl", "-d", "/dev/video0", "--set-ctrl=sharpness=1"])

    subprocess.call(["v4l2-ctl", "-d","/dev/video1", "--set-ctrl=exposure_auto=1"])
    subprocess.call(["v4l2-ctl", "-d","/dev/video1", "--set-ctrl=exposure_absolute=26"]) # 26
    subprocess.call(["v4l2-ctl", "-d", "/dev/video1", "--set-ctrl=gamma=111"])
    subprocess.call(["v4l2-ctl", "-d", "/dev/video1", "--set-ctrl=sharpness=1"])

    subprocess.call(["v4l2-ctl", "-d","/dev/video2", "--set-ctrl=exposure_auto=1"])
    subprocess.call(["v4l2-ctl", "-d","/dev/video2", "--set-ctrl=exposure_absolute=26"]) # 31
    subprocess.call(["v4l2-ctl", "-d", "/dev/video2", "--set-ctrl=gamma=112"])
    subprocess.call(["v4l2-ctl", "-d", "/dev/video2", "--set-ctrl=sharpness=1"])

    cam1 = ( 
        "v4l2src device=/dev/video0 ! "
        "image/jpeg, width={}, height={}, framerate={} ! " 
        "jpegdec ! videoconvert ! videobalance brightness=0.01 contrast=0.9 saturation=1.42 ! appsink" # 0.01 0.89 1.33
        ).format(width, height, framerate)

    cam2 = (
        "v4l2src device=/dev/video1 ! "
        "image/jpeg, width={}, height={}, framerate={} ! "
        "jpegdec ! videoconvert ! videobalance brightness=0.01 contrast=0.9 saturation=1.42 ! appsink" # -0.02
    ).format(width,height,framerate)

    cam3 = (
        "v4l2src device=/dev/video2 ! "
        "image/jpeg, width={}, height={}, framerate={} ! "
        "jpegdec ! videoconvert ! videobalance brightness=0.01 contrast=0.9 saturation=1.42 ! appsink"
    ).format(width,height,framerate)

    camlist = [cam1, cam2, cam3]
    # camlist = [cam1]
    processes = []; cammatrices = []; warpmatrices = []; flag = []

    for num in range(0,3):
        file = open ("/home/fsb/Desktop/diplomski_opencv/intrinsic_calibration/calibration_cam{}.pkl".format(num), "rb") 
        cammatrix = pickle.load(file)
        file.close()
        cammatrices.append(cammatrix)
        
        file = open("/home/fsb/Desktop/diplomski_opencv/tkinter/matrixwarp{}.pkl".format(num), "rb")
        warp = pickle.load(file)
        file.close()
        warpmatrices.append(warp)
        
        flag.append(num)

    for cam, matrix, warpmatrix, flagnum in zip (camlist, cammatrices, warpmatrices, flag):
        p = Process(target=process_camera, args=(cam, matrix, warpmatrix, flagnum, scorelist,))
        p.daemon = True
        p.start()
        processes.append(p)
            
    root = tk.Tk()
    root.title("Darts Scoring")

    entry1 = tk.Entry(root, width=5, bg="gray65", bd=3, justify="center", font=("Arial", 14))
    entry1.place(x=50, y=250)
    entry2 = tk.Entry(root, width=5, bg="gray65", bd=3, justify="center", font=("Arial", 14))
    entry2.place(x=150, y=250)
    entry3 = tk.Entry(root, width=5, bg="gray65", bd=3, justify="center", font=("Arial", 14))
    entry3.place(x=250, y=250)

    entry_total = tk.Entry(root, width=10, bg="gray65", bd=3, justify="center", font=("Arial", 14))
    entry_total.place(x=350, y=250)

    entry1.bind('<Return>', lambda event: updatescore(entry1, entry2, entry3, entry_total))
    entry2.bind('<Return>', lambda event: updatescore(entry1, entry2, entry3, entry_total))
    entry3.bind('<Return>', lambda event: updatescore(entry1, entry2, entry3, entry_total))

    gui_thread = Thread(target=update_gui, args=(entry1, entry2, entry3, entry_total, scorelist))
    gui_thread.daemon = True
    gui_thread.start()

    root.mainloop()

if __name__ == "__main__":
    main()

