import cv2 as cv
import keyboard as key
# width1 = 800 ; height1 = 600; framerate = "10/1"
# subprocess.call(["v4l2-ctl", "-d","/dev/video0", "--set-ctrl=exposure_auto=1"])
# subprocess.call(["v4l2-ctl", "-d","/dev/video0", "--set-ctrl=exposure_absolute=34"]) # 34
# subprocess.call(["v4l2-ctl", "-d", "/dev/video0", "--set-ctrl=gamma=112"])
# subprocess.call(["v4l2-ctl", "-d", "/dev/video0", "--set-ctrl=sharpness=4"])

# cam1 = ( 
#     "v4l2src device=/dev/video0 ! "
#     "image/jpeg, width={}, height={}, framerate={} ! " 
#     "jpegdec ! videoconvert ! videobalance brightness=0.01 contrast=0.89 saturation=1.34 ! appsink" # 0.01 0.89 1.33
#     ).format(width1, height1, framerate)


class Scenechange:
    def __init__(self, camera):
        self.cap = cv.VideoCapture(camera, cv.CAP_GSTREAMER)
        self.prev_frame = None; self.refframe = None; self.frame = None
        self.flag = True; self.flag2 = True; self.newread = False; self.thrown = 0

    def detect_scene_change(self):
        if self.newread:
            self.prev_frame = None; self.refframe = None; self.frame = None
            self.flag = True; self.flag2 = True
            
        while True:
            if self.thrown == 3:
                key.wait("shift") # space
                print("\nNext player.")
                for _ in range(10): # buffer remove pictures 
                    ret, self.frame = self.cap.read()
                self.thrown = 0
            ret, self.frame = self.cap.read()
            
            if not ret:
                print("Error: Unable to capture frame.")
                break
            
            if self.prev_frame is not None:
                diff = cv.absdiff(self.frame, self.prev_frame)
                gray_diff = cv.cvtColor(diff, cv.COLOR_BGR2GRAY)
                _, thresh = cv.threshold(gray_diff, 50, 255, cv.THRESH_BINARY)
                contours, _ = cv.findContours(thresh, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
                largest = max(contours, key=cv.contourArea)
                if 100 < cv.contourArea(largest):
                    if self.flag:
                        self.refframe = self.prev_frame
                        self.flag = False
                        self.flag2 = False
                elif self.flag2 == False:
                    self.newread = True
                    for _ in range(10):
                        ret, self.frame = self.cap.read()
                    self.thrown  += 1
                    return self.refframe, self.frame
                    
            self.prev_frame = self.frame

    def release(self):
        self.cap.release()

# if __name__ == "__main__":
#     stream_url = "your_camera_stream_url"
#     detector = SceneChangeDetector(cam1)
    
#     prevframe, frame = detector.detect_scene_change()
#     cv.imwrite("/home/fsb/Desktop/diplomski_opencv/tkinter/nodart.png", prevframe)
#     cv.imwrite("/home/fsb/Desktop/diplomski_opencv/tkinter/dart.png", frame)
#     detector.release()

#     cv.imshow("prevframe", prevframe)
#     cv.imshow("frame", frame)
#     cv.waitKey(0)
#     cv.destroyAllWindows()
