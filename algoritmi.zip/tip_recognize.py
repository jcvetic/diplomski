import cv2 as cv
import numpy as np
import pickle
import subprocess
import math 

# width1 = 800; height1 = 600; framerate = "30/1"

# subprocess.call(["v4l2-ctl", "-d","/dev/video0", "--set-ctrl=exposure_auto=1"])
# subprocess.call(["v4l2-ctl", "-d","/dev/video0", "--set-ctrl=exposure_absolute=34"]) # 34
# subprocess.call(["v4l2-ctl", "-d", "/dev/video0", "--set-ctrl=gamma=112"])
# subprocess.call(["v4l2-ctl", "-d", "/dev/video0", "--set-ctrl=sharpness=4"])

# subprocess.call(["v4l2-ctl", "-d","/dev/video1", "--set-ctrl=exposure_auto=1"])
# subprocess.call(["v4l2-ctl", "-d","/dev/video1", "--set-ctrl=exposure_absolute=27"]) # 28
# subprocess.call(["v4l2-ctl", "-d", "/dev/video1", "--set-ctrl=gamma=111"])
# subprocess.call(["v4l2-ctl", "-d", "/dev/video1", "--set-ctrl=sharpness=4"])

# subprocess.call(["v4l2-ctl", "-d","/dev/video2", "--set-ctrl=exposure_auto=1"])
# subprocess.call(["v4l2-ctl", "-d","/dev/video2", "--set-ctrl=exposure_absolute=28"]) # 31
# subprocess.call(["v4l2-ctl", "-d", "/dev/video2", "--set-ctrl=gamma=112"])
# subprocess.call(["v4l2-ctl", "-d", "/dev/video2", "--set-ctrl=sharpness=4"])

# cam1 = ( 
#     "v4l2src device=/dev/video0 ! "
#     "image/jpeg, width={}, height={}, framerate={} ! " 
#     "jpegdec ! videoconvert ! videobalance brightness=0.01 contrast=0.89 saturation=1.34 ! appsink" # 0.01 0.89 1.33
#     ).format(width1, height1, framerate)

# cam2 = (
#     "v4l2src device=/dev/video1 ! "
#     "image/jpeg, width={}, height={}, framerate={} ! "
#     "jpegdec ! videoconvert ! videobalance brightness=-0.01 contrast=0.87 saturation=1.35 ! appsink" # -0.02
# ).format(width1,height1,framerate)

# cam3 = (
#     "v4l2src device=/dev/video2 ! "
#     "image/jpeg, width={}, height={}, framerate={} ! "
#     "jpegdec ! videoconvert ! videobalance brightness=0.01 contrast=0.87 saturation=1.35 ! appsink"
# ).format(width1,height1,framerate)

# camlist = [cam1,cam2,cam3]

# def rawdartboard_all():
#     num = 0
#     while True:
#         cap1 = cv.VideoCapture(cam1,cv.CAP_GSTREAMER)
#         cap2 = cv.VideoCapture(cam2,cv.CAP_GSTREAMER)
#         cap3 = cv.VideoCapture(cam3,cv.CAP_GSTREAMER)
#         while True:
#             ret1, img1 = cap1.read()
#             ret2, img2 = cap2.read()
#             ret3, img3 = cap3.read()
#             if ret1 and ret2 and ret3 == True:
#                 cv.imshow("cam1",img1)
#                 cv.imshow("cam2",img2)
#                 cv.imshow("cam3",img3)
#                 k = cv.waitKey(5)
                
#                 if k == ord('s'):
#                     cv.imwrite("/home/fsb/Desktop/diplomski_opencv/darts_tip_recognition/allcam/dartboard{}.png".format(num), img1)
#                     num += 1
#                     cv.imwrite("/home/fsb/Desktop/diplomski_opencv/darts_tip_recognition/allcam/dartboard{}.png".format(num), img2)
#                     num += 1
#                     cv.imwrite("/home/fsb/Desktop/diplomski_opencv/darts_tip_recognition/allcam/dartboard{}.png".format(num), img3)
#                     num += 1
#                     print('\nPicture {} is saved.'.format(num))
#                 else:
#                     pass
#     cap1.release()
#     cap2.release()
#     cap3.release()
#     cv.destroyAllWindows()

# def rawdartboard():
#     current_cam = cam1
#     num = 0
#     cap1 = cv.VideoCapture(current_cam,cv.CAP_GSTREAMER)
#     while True:
#         ret, img1 = cap1.read()
#         if ret == True:
#             cv.imshow("image",img1)
#             k = cv.waitKey(5)
#             if k == ord('s'):
#                 cv.imwrite("/home/fsb/Desktop/diplomski_opencv/darts_tip_recognition/campic/dartboard{}.png".format(num), img1)
#                 imgnew = cv.imread("/home/fsb/Desktop/diplomski_opencv/darts_tip_recognition/campic/dartboard{}.png".format(num))
#                 print('\nPicture {} is saved.'.format(num))
#                 num += 1
#             else:
#                 pass
#     cap1.release()
#     cv.destroyAllWindows()

camnum = 0

def extractdart(nodart,dart, cammatrix):
    intrmatrix = cammatrix[0]; distcoefs = cammatrix[1]

    ############## UNDISTORTION #####################################################
    h,w = nodart.shape[:2]
    newintrmatrix, roi = cv.getOptimalNewCameraMatrix(intrmatrix, distcoefs, (w,h), 1, (w,h))

    # Undistort
    nodart = cv.undistort(nodart, intrmatrix, distcoefs, None, newintrmatrix)
    dart = cv.undistort(dart, intrmatrix, distcoefs, None, newintrmatrix)

    # crop the image
    x, y, w, h = roi
    nodart = nodart[y:y+h, x:x+w]
    dart = dart[y:y+h, x:x+w]
    img = dart.copy()

    diff = cv.absdiff(dart,nodart)
    # cv.imwrite("/home/fsb/Desktop/diplomski_opencv/darts_tip_recognition/campic/nodart.png", nodart)
    # cv.imwrite("/home/fsb/Desktop/diplomski_opencv/darts_tip_recognition/campic/dart.png", dart)
    diff = cv.cvtColor(diff, cv.COLOR_BGR2GRAY)
    meandiff = diff.copy()
    # cv.imshow("absdiff", diff)
    # cv.imshow("first-diff",diff)
    # diff = cv.fastNlMeansDenoising(diff, None, 5)
    # cv.imshow("fast", diff)
    # diff = cv.medianBlur(diff, 5)
    # cv.imshow("med", diff2)
    kernel = np.ones((5,5), np.float32) / 25 # type:ignore - 6,6,36 
    diff = cv.filter2D(diff,-1,kernel)
    _, thresh = cv.threshold(diff, 20, 255, cv.THRESH_BINARY)
    # cv.imshow("thresh", thresh)
    kernel = np.ones((3,3), np.uint8) # type: ignore ###    KAKO ISKLJUCITI DA SE PREPOZNA KONTURA PLOCE - KAKO PREPOIZNATI SAMO STRELICU U SVIM SLUCAJEVIMA!!!!!!????????????????????
    diff = cv.dilate(thresh, kernel, iterations = 1)
    # cv.imshow("dilate",diff)
    
    kernel = cv.getStructuringElement(cv.MORPH_RECT, (9,9)) # 9,9
    diff = cv.morphologyEx(diff, cv.MORPH_CLOSE, kernel, iterations=1) # close, (9,9), (2) 
    # cv.imshow("diff", diff)
    # cv.waitKey(0)
    cont, _ = cv.findContours(diff, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_NONE) # bio diff na findcontours
    
    contlist = []; bigcont = []
    for c in cont:
        if cv.contourArea(c) > 300:
            check = np.zeros_like(diff)
            cv.drawContours(check, [c], -1, (255), cv.FILLED)
            meanint = np.mean(meandiff[check == 255])
            if meanint > 40: 
                bigcont = max(cont,key=cv.contourArea)
                contlist.append(bigcont)
    
    rect = cv.minAreaRect(bigcont) 
    box = cv.boxPoints(rect)
    transbox = box - np.mean(box,axis=0)
    scaledbox = transbox * 1.25
    retransbox = scaledbox + np.mean(box,axis=0)
    box = np.int0(retransbox) #type:ignore
    boxmask = np.zeros_like(diff)
    cv.drawContours(boxmask, [box], 0, (255,255,255), cv.FILLED)
    cv.drawContours(img, [box], 0, (255,0,0), 2)
    boxmask = cv.bitwise_and(thresh,thresh,mask=boxmask) # bio diff, diff
    boxmask = cv.cvtColor(boxmask, cv.COLOR_GRAY2BGR)
    cv.drawContours(img, contlist, -1, (255,0,0), 2) 
    # cv.imshow("box", boxmask)
    # cv.imshow("imageimage", img)
    # cv.waitKey(0)
    # cv.destroyAllWindows()
    return img,nodart,dart,boxmask,contlist, thresh

scale2list = np.linspace(0.7,1.3,65)
def findpoint(img,nodart,dart,boxmask,contlist, cammatrix, flagnum, thresh):
    scale = 0
    intdiff = 30 # 40
    diffcount1 = 0; diffcount2 = 0
    intlist1 = []; intlist2 = []
    avg1 = 0; avg2 = 0
    contthresh, _ = cv.findContours(thresh, cv.RETR_EXTERNAL,cv.CHAIN_APPROX_NONE)
    cv.drawContours(img,contthresh,-1, (255,0,0), 1) # contlist bio
    for i,c in enumerate(contlist):
        datapts = np.empty((len(c),2), dtype=np.float64) #type: ignore
        for k in range(datapts.shape[0]):  
            datapts[k,0] = c[k,0,0]
            datapts[k,1] = c[k,0,1]
        mean, eigenvectors, eigenvalues = cv.PCACompute2(datapts, np.empty((0)))
        cntr = (int(mean[0,0]), int(mean[0,1]))
        cv.circle(img,cntr,1,(255,0,255),2)
                
        contmask = np.zeros_like(dart)
        cv.drawContours(contmask,contlist,-1, (255,255,255),-1) # contlist bio i contthresh
        
        res = cv.bitwise_and(dart,contmask) # bio contmask
        res = cv.cvtColor(res,cv.COLOR_BGR2GRAY)

        # cv.imshow("res", res)
        # cv.waitKey(0)
        # cv.destroyAllWindows()
        while True:
            p1 = (cntr[0] - scale*eigenvectors[0,0]*eigenvalues[0,0], cntr[1] - scale*eigenvectors[0,1]*eigenvalues[0,0])
            p2 = (cntr[0] + scale*eigenvectors[0,0]*eigenvalues[0,0], cntr[1] + scale*eigenvectors[0,1]*eigenvalues[0,0])
            x1 = int(p1[0]); y1 = int(p1[1]); x2 = int(p2[0]); y2 = int(p2[1])
            pt1 = (x1,y1); pt2 = (x2,y2)
            int1 = int(res[y1,x1]); int2 = int(res[y2,x2])
            # print(int1); print(int2)
            ptcont1 = cv.pointPolygonTest(contlist[0], pt1, False) # bio contlist[0]
            ptcont2 = cv.pointPolygonTest(contlist[0], pt2, False)

            if ptcont1 == -1 and ptcont2 == -1:
                intlist1 = sorted(intlist1); intlist2 = sorted(intlist2) # dodano 1.maj
                # cv.imshow("img", img)
                # cv.waitKey(0)
                # cv.destroyAllWindows()
                # avg1 = int(sum(intlist1) / len(intlist1)); avg2 = int(sum(intlist2) / len(intlist2))
                mid1 = intlist1[len(intlist1) // 2]; mid2 = intlist2[len(intlist2) // 2]
                # print(avg1); print(avg2)
                # print(mid1); print(mid2)
                # print(intlist1); print(intlist2)
                if mid1 > mid2:
                    pointlist = []
                    for scale2 in scale2list:
                        scale = 0
                        groundval = [255,255,255]
                        prevval = (0,0,0); currpos = 0; prevpos = 0
                        valcount = 0
                        while True:
                            p2 = (cntr[0] + scale*scale2*eigenvectors[0,0]*eigenvalues[0,0], cntr[1] + scale*eigenvectors[0,1]*eigenvalues[0,0])
                            x2 = int(p2[0]); y2 = int(p2[1]) # p2
                            val = boxmask[y2,x2]
                            if val[0] != groundval[0]:
                                if val[0] != prevval[0]:
                                    currpos = prevpos
                                valcount += 1   
                                if valcount == 50:
                                    # cv.line(boxmask,cntr,currpos,(0,0,255), 1)
                                    # cv.circle(boxmask, currpos, 1, (0,255,0),1)
                                    pointlist.append(currpos)
                                    break
                            prevval = boxmask[y2,x2]
                            prevpos = (x2,y2)
                            scale += 1e-4
                    
                    prevdist = 0
                    for point in pointlist:
                        dist = ((point[0]-cntr[0]) ** 2 + ((point[1])-cntr[1]) ** 2) ** 0.5
                        if dist > prevdist:
                            prevdist = dist 
                            finalpoint = point
                    break
                else:
                    pointlist = []
                    for scale2 in scale2list:
                        scale = 0
                        groundval = [255,255,255]
                        prevval = (0,0,0); currpos = 0; prevpos = 0
                        valcount = 0
                        while True:
                            p1 = (cntr[0] - scale*scale2*eigenvectors[0,0]*eigenvalues[0,0], cntr[1] - scale*eigenvectors[0,1]*eigenvalues[0,0])
                            x1 = int(p1[0]); y1 = int(p1[1])
                            val = boxmask[y1,x1]
                            if val[0] != groundval[0]:
                                if val[0] != prevval[0]:
                                    currpos = prevpos
                                valcount += 1   
                                if valcount == 50:
                                    # cv.line(boxmask,cntr,currpos,(0,0,255), 1)
                                    # cv.circle(boxmask, currpos, 1, (0,255,0),1)
                                    pointlist.append(currpos)
                                    break
                            prevval = boxmask[y1,x1]
                            prevpos = (x1,y1)
                            scale += 1e-4
                    
                    prevdist = 0
                    for point in pointlist:
                        dist = ((point[0]-cntr[0]) ** 2 + ((point[1])-cntr[1]) ** 2) ** 0.5
                        if dist > prevdist:
                            prevdist = dist 
                            finalpoint = point
                    break
                
            elif abs(int1-int2) > intdiff and 50 < int1 < 220 and 50 < int2 < 220: ## PROBLEM SA VELICINOM KONTURE - NACRTANA KONTURA VECA OD STVARNE, ULAZI U IZRACUN I OVAJ DIO KOJI NIJE NA STVARNOJ KONTURI, ISCRTA SE pt1 i pt2 izvan stvarne strelice!!
                if not ptcont1 == -1 and not ptcont2 == -1:
                    intlist1.append(int1)
                    intlist2.append(int2)
                    cv.circle(img, pt1, 1, (0,0,255),1)
                    cv.circle(img, pt2, 1, (0,255,0),1)
                # if ptcont2 == 1:
                #     intlist2.append(int2)
                #     cv.circle(img, pt2, 1, (0,255,0),1)
                    
                
            # if abs(int1-int2) > intdiff:
            #     if not ptcont1 == -1 and not ptcont2 == -1:
            #         if int1 > int2:
            #             cv.circle(img, (x1,y1), 1, (255,255,0), 4)
            #             cv.circle(img, (x2,y2), 1, (0,0,255), 4)
            #             # cv.line(img, (int(p1[0]), int(p1[1])), (int(p2[0]), int(p2[1])), (0,0,255), 2)
            #             # print("\nInt1 is brighter pixel")
            #             # print(int1,int2)
            #             diffcount1 += 1
            #             if diffcount1 == 7: ## if diffcount1 == 7
            #                 pointlist = []
            #                 for scale2 in scale2list:
            #                     scale = 0
            #                     groundval = [255,255,255]
            #                     prevval = (0,0,0); currpos = 0
            #                     valcount = 0
            #                     while True:
            #                         p2 = (cntr[0] + scale*scale2*eigenvectors[0,0]*eigenvalues[0,0], cntr[1] + scale*eigenvectors[0,1]*eigenvalues[0,0])
            #                         x2 = int(p2[0]); y2 = int(p2[1]) # p2
            #                         val = boxmask[y2,x2]
            #                         if val[0] != groundval[0]:
            #                             if val[0] != prevval[0]:
            #                                 currpos = (x2,y2)
            #                             valcount += 1   
            #                             if valcount == 50:
            #                                 # cv.line(boxmask,cntr,currpos,(0,0,255), 1)
            #                                 # cv.circle(boxmask, currpos, 1, (0,255,0),1)
            #                                 pointlist.append(currpos)
            #                                 break
            #                         prevval = boxmask[y2,x2]
            #                         scale += 1e-4
                            
            #                 prevdist = 0
            #                 for point in pointlist:
            #                     dist = ((point[0]-cntr[0]) ** 2 + ((point[1])-cntr[1]) ** 2) ** 0.5
            #                     if dist > prevdist:
            #                         prevdist = dist 
            #                         finalpoint = point
            #                 break
            #         else:
            #             cv.circle(img, (x2,y2), 1, (0,0,255), 4)
            #             cv.circle(img, (x1,y1), 1, (255,255,0), 4)
            #             # cv.line(img, (int(p1[0]), int(p1[1])), (int(p2[0]), int(p2[1])), (0,0,255), 2)
            #             # print(int1,int2)
            #             # print("\nInt2 is brighter pixel")
            #             diffcount2 += 1
            #             if diffcount2 == 7:
            #                 pointlist = []
            #                 for scale2 in scale2list:
            #                     scale = 0
            #                     groundval = [255,255,255]
            #                     prevval = (0,0,0); currpos = 0
            #                     valcount = 0
            #                     while True:
            #                         p1 = (cntr[0] - scale*scale2*eigenvectors[0,0]*eigenvalues[0,0], cntr[1] - scale*eigenvectors[0,1]*eigenvalues[0,0])
            #                         x1 = int(p1[0]); y1 = int(p1[1])
            #                         val = boxmask[y1,x1]
            #                         if val[0] != groundval[0]:
            #                             if val[0] != prevval[0]:
            #                                 currpos = (x1,y1)
            #                             valcount += 1   
            #                             if valcount == 50:
            #                                 # cv.line(boxmask,cntr,currpos,(0,0,255), 1)
            #                                 # cv.circle(boxmask, currpos, 1, (0,255,0),1)
            #                                 pointlist.append(currpos)
            #                                 break
            #                         prevval = boxmask[y1,x1]
            #                         scale += 1e-4
                            
            #                 prevdist = 0
            #                 for point in pointlist:
            #                     dist = ((point[0]-cntr[0]) ** 2 + ((point[1])-cntr[1]) ** 2) ** 0.5
            #                     if dist > prevdist:
            #                         prevdist = dist 
            #                         finalpoint = point
            #                 break
            #     else:
            #         avg1 = int(sum(intlist1) / len(intlist1)); avg2 = int(sum(intlist2) / len(intlist2))
            #         if avg1 > avg2:
            #             pointlist = []
            #             for scale2 in scale2list:
            #                 scale = 0
            #                 groundval = [255,255,255]
            #                 prevval = (0,0,0); currpos = 0
            #                 valcount = 0
            #                 while True:
            #                     p2 = (cntr[0] + scale*scale2*eigenvectors[0,0]*eigenvalues[0,0], cntr[1] + scale*eigenvectors[0,1]*eigenvalues[0,0])
            #                     x2 = int(p2[0]); y2 = int(p2[1]) # p2
            #                     val = boxmask[y2,x2]
            #                     if val[0] != groundval[0]:
            #                         if val[0] != prevval[0]:
            #                             currpos = (x2,y2)
            #                         valcount += 1   
            #                         if valcount == 50:
            #                             # cv.line(boxmask,cntr,currpos,(0,0,255), 1)
            #                             # cv.circle(boxmask, currpos, 1, (0,255,0),1)
            #                             pointlist.append(currpos)
            #                             break
            #                     prevval = boxmask[y2,x2]
            #                     scale += 1e-4
                        
            #             prevdist = 0
            #             for point in pointlist:
            #                 dist = ((point[0]-cntr[0]) ** 2 + ((point[1])-cntr[1]) ** 2) ** 0.5
            #                 if dist > prevdist:
            #                     prevdist = dist 
            #                     finalpoint = point
            #             break
            #         else:
            #             pointlist = []
            #             for scale2 in scale2list:
            #                 scale = 0
            #                 groundval = [255,255,255]
            #                 prevval = (0,0,0); currpos = 0
            #                 valcount = 0
            #                 while True:
            #                     p1 = (cntr[0] - scale*scale2*eigenvectors[0,0]*eigenvalues[0,0], cntr[1] - scale*eigenvectors[0,1]*eigenvalues[0,0])
            #                     x1 = int(p1[0]); y1 = int(p1[1])
            #                     val = boxmask[y1,x1]
            #                     if val[0] != groundval[0]:
            #                         if val[0] != prevval[0]:
            #                             currpos = (x1,y1)
            #                         valcount += 1   
            #                         if valcount == 50:
            #                             # cv.line(boxmask,cntr,currpos,(0,0,255), 1)
            #                             # cv.circle(boxmask, currpos, 1, (0,255,0),1)
            #                             pointlist.append(currpos)
            #                             break
            #                     prevval = boxmask[y1,x1]
            #                     scale += 1e-4
                        
            #             prevdist = 0
            #             for point in pointlist:
            #                 dist = ((point[0]-cntr[0]) ** 2 + ((point[1])-cntr[1]) ** 2) ** 0.5
            #                 if dist > prevdist:
            #                     prevdist = dist 
            #                     finalpoint = point
            #             break
                        
            scale += 1e-4
    nodart = cv.warpPerspective(nodart,cammatrix,dsize = (950,950), flags=cv.INTER_NEAREST)
    point = np.array([[finalpoint[0], finalpoint[1]]], dtype="float32") # type:ignore
    point = np.array([point])
    point2 = cv.perspectiveTransform(point, cammatrix)
    point2 = tuple((point2[0][0]))
    point = (int(point2[0]), int(point2[1]))
    
    if flagnum == 2:
        point = (950-point[0]-1,point[1])
        nodart = cv.flip(nodart,1)
    cv.circle(img, finalpoint, 1, (0,255,255),1)
    # cv.imshow("img", img)
    # cv.waitKey(0)
    # cv.destroyAllWindows()
    return point, nodart

centercir = [(474,478),(478,480),(474,476)] # (25-50), (triple), (double) - center x,y position
refpoint = [(625,180),(627,181),(625,180)]
regions = [14,32,191,211,315,335] # regions for multiplier
refanglelist = [63.128,63.511,62.972]

def getscore(point, nodart, flagnum):
    score = 0
    cv.circle(nodart, (point[0],point[1]), 1, (0,255,255),2)
    cv.circle(nodart, centercir[flagnum],1,(0,255,0),2) 
    cv.circle(nodart, refpoint[flagnum], 1, (127,255,127),2)
    cv.line(nodart, centercir[flagnum], refpoint[flagnum], (0,255,255), 1)
    
    dist = round(((point[0]-centercir[flagnum][0]) ** 2 + ((point[1])-centercir[flagnum][1]) ** 2) ** 0.5, 2)
    
    # refdir1 = (refpoint[flagnum][0] - centercir[flagnum][0])
    # refdir2 = (refpoint[flagnum][1] - centercir[flagnum][1])
    # refangle = ((math.atan2(refdir2,refdir1)) * 180) / np.pi # type: ignore - cca.62.6deg - cam0
    # print(refangle)
    refangle = refanglelist[flagnum]
    
    dir1 = (point[0] - centercir[flagnum][0])
    dir2 = (centercir[flagnum][1] - point[1])
    angle = math.fmod(((((math.atan2(dir2,dir1)) * 180) / np.pi) + 360 - refangle), 360) # type: ignore
    region = angle // 18.0

    if region == 0:
        score = 5
    elif region == 1:
        score = 12
    elif region == 2:
        score = 9
    elif region == 3:
        score = 14
    elif region == 4:
        score = 11
    elif region == 5:
        score = 8
    elif region == 6:
        score = 16
    elif region == 7:
        score = 7
    elif region == 8:
        score = 19
    elif region == 9:
        score = 3
    elif region == 10:
        score = 17
    elif region == 11:
        score = 2
    elif region == 12:
        score = 15
    elif region == 13:
        score = 10
    elif region == 14:
        score = 6
    elif region == 15:
        score = 13
    elif region == 16:
        score = 4
    elif region == 17:
        score = 18
    elif region == 18:
        score = 1
    elif region == 19:
        score = 20
    else:
        print("Error calculating score.")
    
    # if dist <= regions[1]:
    #     dist = round(((point[0]-centercir[flagnum][0]) ** 2 + ((point[1])-centercir[flagnum][1]) ** 2) ** 0.5, 2)
    # elif dist <= regions[3]:
    #     dist = round(((point[0]-centercir[flagnum][0]) ** 2 + ((point[1])-centercir[flagnum][1]) ** 2) ** 0.5, 2)
    # else:
    #     dist = round(((point[0]-centercir[flagnum][0]) ** 2 + ((point[1])-centercir[flagnum][1]) ** 2) ** 0.5, 2)
    
    for distcount in range(0,6):
        if dist <= regions[distcount]:
            if distcount == 0:
                score = 50
                # print("Multiplier x score:")
                # print("1 x 50")
            elif distcount == 1:
                score = 25
                # print("Multiplier x score:")
                # print("1 x 25")
            elif distcount == 2 or distcount == 4:
                # print("Multiplier x score:")
                # print("1 x {}".format(score))
                score *= 1
            elif distcount == 3:
                # print("Multiplier x score:")
                # print("3 x {}".format(score))
                score *= 3
            elif distcount == 5:
                # print("Multiplier x score:")
                # print("2 x {}".format(score))
                score *= 2
            break
        
    if dist > regions[5]:
        score = 0
        # print("No score.")

    # cv.imshow("nodart", nodart)
    # cv.waitKey(0)
    # cv.destroyAllWindows()
    
    return score

# rawdartboard()
# # rawdartboard_all()
# img,nodart,dart,boxmask,contlist = extractdart(nodart, dart)
# point, nodart = findpoint(img,nodart,dart,boxmask,contlist)
# getscore(point, nodart)

if __name__ == "__main__":
    num = 0
    flagnum = 0
    width = 800; height = 600; framerate = "5/1"
    flag = 0
    
    subprocess.call(["v4l2-ctl", "-d","/dev/video0", "--set-ctrl=exposure_auto=1"])
    subprocess.call(["v4l2-ctl", "-d","/dev/video0", "--set-ctrl=exposure_absolute=26"]) # 34 -- Mijenjaj EKSPOZICIJU OVISNO O VANJSKOM SVJETLU - CILJ IMATI INFO O STRELICI!!!!!!!!!!
    subprocess.call(["v4l2-ctl", "-d", "/dev/video0", "--set-ctrl=gamma=112"])
    subprocess.call(["v4l2-ctl", "-d", "/dev/video0", "--set-ctrl=sharpness=1"])

    subprocess.call(["v4l2-ctl", "-d","/dev/video1", "--set-ctrl=exposure_auto=1"])
    subprocess.call(["v4l2-ctl", "-d","/dev/video1", "--set-ctrl=exposure_absolute=26"]) # 26
    subprocess.call(["v4l2-ctl", "-d", "/dev/video1", "--set-ctrl=gamma=111"])
    subprocess.call(["v4l2-ctl", "-d", "/dev/video1", "--set-ctrl=sharpness=1"])

    subprocess.call(["v4l2-ctl", "-d","/dev/video2", "--set-ctrl=exposure_auto=1"])
    subprocess.call(["v4l2-ctl", "-d","/dev/video2", "--set-ctrl=exposure_absolute=26"]) # 31
    subprocess.call(["v4l2-ctl", "-d", "/dev/video2", "--set-ctrl=gamma=112"])
    subprocess.call(["v4l2-ctl", "-d", "/dev/video2", "--set-ctrl=sharpness=1"])

    cam1 = ( 
        "v4l2src device=/dev/video0 ! "
        "image/jpeg, width={}, height={}, framerate={} ! " 
        "jpegdec ! videoconvert ! videobalance brightness=0.01 contrast=0.9 saturation=1.42 ! appsink" # 0.01 0.89 1.33
        ).format(width, height, framerate)

    cam2 = (
        "v4l2src device=/dev/video1 ! "
        "image/jpeg, width={}, height={}, framerate={} ! "
        "jpegdec ! videoconvert ! videobalance brightness=0.01 contrast=0.9 saturation=1.42 ! appsink" # -0.02
    ).format(width,height,framerate)

    cam3 = (
        "v4l2src device=/dev/video2 ! "
        "image/jpeg, width={}, height={}, framerate={} ! "
        "jpegdec ! videoconvert ! videobalance brightness=0.01 contrast=0.9 saturation=1.42 ! appsink"
    ).format(width,height,framerate)
    
    # rawdartboard()
    
#     # cap = cv.VideoCapture(cam1,cv.CAP_GSTREAMER)
#     # while True:  
#     #     ret, frame = cap.read()  
#     #     if ret:
#     #         cv.imshow("frame", frame)
#     #         k = cv.waitKey(10)
#     #         if k == ord('s') and flag == 0 :
#     #             cv.imwrite('/home/fsb/Desktop/diplomski_opencv/tkinter/nodart.png', frame)
#     #             flag = 1
#     #         elif k == ord('s') and flag == 1:
#     #             cv.imwrite('/home/fsb/Desktop/diplomski_opencv/tkinter/dart.png', frame)
#     #             break
#     #         else:
#     #             pass
#     # cap.release()
#     # cv.destroyAllWindows()

            
    nodart = cv.imread('/home/fsb/Desktop/diplomski_opencv/darts_tip_recognition/campic/nodart.png')
    dart = cv.imread('/home/fsb/Desktop/diplomski_opencv/darts_tip_recognition/campic/dart.png')
    file = open ("/home/fsb/Desktop/diplomski_opencv/intrinsic_calibration/calibration_cam{}.pkl".format(num), "rb") 
    cammatrix = pickle.load(file)
    file.close()
    
    file = open("/home/fsb/Desktop/diplomski_opencv/tkinter/matrixwarp{}.pkl".format(num), "rb")
    warp = pickle.load(file)
    file.close()
    
    img,nodart,dart,boxmask,contlist, thresh = extractdart(nodart,dart, cammatrix)
    point, nodart = findpoint(img,nodart,dart,boxmask,contlist, warp, flagnum, thresh)
    score = getscore(point, nodart, flagnum)