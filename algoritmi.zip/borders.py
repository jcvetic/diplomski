import cv2 as cv
import numpy as np
import math, pickle, subprocess

anglenum = 0
width1 = 800; height1 = 600; framerate = "30/1"
subprocess.call(["v4l2-ctl", "-d","/dev/video0", "--set-ctrl=exposure_auto=1"])
subprocess.call(["v4l2-ctl", "-d","/dev/video0", "--set-ctrl=exposure_absolute=30"]) # 34 -- Mijenjaj EKSPOZICIJU OVISNO O VANJSKOM SVJETLU - CILJ IMATI INFO O STRELICI!!!!!!!!!!
subprocess.call(["v4l2-ctl", "-d", "/dev/video0", "--set-ctrl=gamma=112"])
subprocess.call(["v4l2-ctl", "-d", "/dev/video0", "--set-ctrl=sharpness=4"])

subprocess.call(["v4l2-ctl", "-d","/dev/video1", "--set-ctrl=exposure_auto=1"])
subprocess.call(["v4l2-ctl", "-d","/dev/video1", "--set-ctrl=exposure_absolute=30"]) # 28
subprocess.call(["v4l2-ctl", "-d", "/dev/video1", "--set-ctrl=gamma=111"])
subprocess.call(["v4l2-ctl", "-d", "/dev/video1", "--set-ctrl=sharpness=4"])

subprocess.call(["v4l2-ctl", "-d","/dev/video2", "--set-ctrl=exposure_auto=1"])
subprocess.call(["v4l2-ctl", "-d","/dev/video2", "--set-ctrl=exposure_absolute=30"]) # 31
subprocess.call(["v4l2-ctl", "-d", "/dev/video2", "--set-ctrl=gamma=112"])
subprocess.call(["v4l2-ctl", "-d", "/dev/video2", "--set-ctrl=sharpness=4"])

cam1 = ( 
    "v4l2src device=/dev/video0 ! "
    "image/jpeg, width={}, height={}, framerate={} ! " 
    "jpegdec ! videoconvert ! videobalance brightness=0.01 contrast=0.89 saturation=1.34 ! appsink" # 0.01 0.89 1.33
    ).format(width1, height1, framerate)

cam2 = (
    "v4l2src device=/dev/video1 ! "
    "image/jpeg, width={}, height={}, framerate={} ! "
    "jpegdec ! videoconvert ! videobalance brightness=-0.01 contrast=0.87 saturation=1.35 ! appsink" # -0.02
).format(width1,height1,framerate)

cam3 = (
    "v4l2src device=/dev/video2 ! "
    "image/jpeg, width={}, height={}, framerate={} ! "
    "jpegdec ! videoconvert ! videobalance brightness=0.01 contrast=0.87 saturation=1.35 ! appsink"
).format(width1,height1,framerate)

camlist = [cam1,cam2,cam3]
# # camlist = [cam1,cam2]
for camera in range(len(camlist)):
    # curcam = camlist[camera]
    # cap = cv.VideoCapture(curcam,cv.CAP_GSTREAMER)
    # while True:  
    #     ret, frame = cap.read()  
    #     if ret:
    #         cv.imshow("frame", frame)
    #         k = cv.waitKey(10)
    #         if k == ord('s'):
    #             dartboard = frame
    #             break
    #         else:
    #             pass
    # cap.release()
    # cv.destroyAllWindows()
    
    # # dartboard = cv.imread("/home/fsb/Desktop/diplomski_opencv/homography/cam0/dartboard{}.png".format(camera))

    # # intrinsic matrix and distortion parameters
    # file = open ("/home/fsb/Desktop/diplomski_opencv/intrinsic_calibration/calibration_cam{}.pkl".format(camera), "rb") 
    # cammatrix = pickle.load(file)
    # file.close()
    # intrmatrix = cammatrix[0]; distcoefs = cammatrix[1]

    # ############## UNDISTORTION #####################################################
    # h,w = dartboard.shape[:2]
    # newintrmatrix, roi = cv.getOptimalNewCameraMatrix(intrmatrix, distcoefs, (w,h), 1, (w,h))

    # # Undistort
    # correctedimage = cv.undistort(dartboard, intrmatrix, distcoefs, None, newintrmatrix)

    # # crop the image
    # x, y, w, h = roi
    # correctedimage = correctedimage[y:y+h, x:x+w]

    # dartboard = correctedimage
    # dartboard2 = correctedimage.copy()
    # dartboard3 = correctedimage.copy()
    # blackcont = np.zeros_like(correctedimage)
    # blackline = np.zeros_like(correctedimage)

    # # cv.imshow("FIRST", dartboard)
    # dartboard = cv.cvtColor(dartboard, cv.COLOR_BGR2HSV)
    # kernel = np.ones((7,7), np.float32) / 49 # type:ignore 
    # dartboard = cv.filter2D(dartboard,-1,kernel)

    # h,s,v = cv.split(dartboard)
    # _, dartboard = cv.threshold(v, 255/3, 255, cv.THRESH_BINARY_INV|cv.THRESH_OTSU)
    # # cv.imshow("THRESHOLDsecond", dartboard)

    # cont, _ = cv.findContours(dartboard, cv.RETR_LIST, cv.CHAIN_APPROX_NONE)

    # for c in cont:
    #     if 50000 < cv.contourArea(c) < 110000:
    #         ellipse = cv.fitEllipse(c)
    #         cv.ellipse(blackcont,ellipse,color = (255,255,255), thickness=2) # type: ignore
            
    # canny = cv.cvtColor(dartboard3, cv.COLOR_BGR2HSV)
    # kernel = np.ones((5,5), np.float32) / 25 # type:ignore 
    # canny = cv.filter2D(canny, -1, kernel)
    # h,s,canny = cv.split(canny)
    
    # _, canny = cv.threshold(canny, 255/2,255,cv.THRESH_BINARY|cv.THRESH_OTSU)
    # canny = cv.Canny(canny,150/2,150, apertureSize=5, L2gradient=True)
    # # cv.imshow("canny", canny)
    # linesparam = [(110,100),(80,90),(100,100)]
    # lines = cv.HoughLines(canny, 1, np.pi/linesparam[camera][0], linesparam[camera][1]) # type: ignore

    # anglelist = [(5,8),(-81,-78),(33,35),(-44,-42),(51,54),(-26,-23)] # -78,-77
    # for i in range(0, len(lines)): 
    #     rho = lines[i][0][0]
    #     theta = lines[i][0][1]
    #     a = math.cos(theta)
    #     b = math.sin(theta)
    #     x0 = a * rho
    #     y0 = b * rho
    #     pt1 = (int(x0 + 1000*(-b)), int(y0 + 1000*(a)))
    #     pt2 = (int(x0 - 1000*(-b)), int(y0 - 1000*(a)))
    #     angle = (math.atan2(pt2[1]-pt1[1], pt2[0]-pt1[0]) * 180.0) / np.pi # type: ignore
    #     # print(angle)
    #     if anglelist[anglenum][0] <= angle <= anglelist[anglenum][1] or anglelist[anglenum+1][0] <= angle <= anglelist[anglenum+1][1]:
    #         cv.line(blackline, pt1, pt2, (255,255,255),2) 
    # anglenum +=2
    # black = cv.bitwise_and(blackcont,blackline)
    # black = cv.cvtColor(black, cv.COLOR_BGR2GRAY)
    # cv.imshow("black",black)
    # contours, _ = cv.findContours(black,cv.RETR_EXTERNAL,cv.CHAIN_APPROX_NONE)
    # avgpoints = []
    # # cv.imshow("dartboard2", dartboard2)

    # for c in contours:
    #     M = cv.moments(c)
    #     cx = int(M["m10"]/M["m00"])
    #     cy = int(M["m01"]/M["m00"])
    #     avgpoint = (cx,cy)
    #     cv.circle(dartboard2,avgpoint,1,(255,0,0),10)
    #     avgpoints.append(avgpoint)
        
    # order = [(0,2,3,1),(2,3,1,0),(0,2,3,1)]

    # avgpoints = [avgpoints[order[camera][0]],avgpoints[order[camera][1]],avgpoints[order[camera][2]],avgpoints[order[camera][3]]]
    # avgpoints = np.float32(avgpoints) # type: ignore

    # points2 = np.float32([[240,240], [715, 240], [715, 715], [240, 715]]) # type: ignore
    # matrix, status = cv.findHomography(avgpoints,points2, cv.RANSAC, 1.0)
    # pickle.dump(matrix, open( "/home/fsb/Desktop/diplomski_opencv/tkinter/matrixwarp{}.pkl".format(camera), "wb"))
    # output = cv.warpPerspective(correctedimage,matrix,dsize = (950,950), flags=cv.INTER_NEAREST)
    # if camera == 2:
    #     output = cv.flip(output,1)
    # cv.imshow('output',output)
    # cv.imwrite("/home/fsb/Desktop/diplomski_opencv/center_align/dartboardhomo{}.png".format(camera), output)
    # cv.imshow("dartboard", dartboard2)
    # cv.waitKey(0)
    # cv.destroyAllWindows()
    
    
# # ## NADI CENTRE PONOVNO KAK SE SPADA!
    blurparam = [(9,9,0.92),(9,9,0.92),(9,9,1.15)] # (1,1.032,1.2), (1.01,1.049,1.02), (1.83,1.4,1.2)
    houghparam = [(1,30,100,50,10,40),(1,30,100,50,10,40),(1,30,100,50,10,40)] # (10,40),    (180,210),    (320,350) 
    circleslist = []

    darthomo = cv.imread("/home/fsb/Desktop/diplomski_opencv/center_align/dartboardhomo{}.png".format(camera))

    gray_darthomo = cv.cvtColor(darthomo, cv.COLOR_BGR2GRAY)
    blur = cv.GaussianBlur(gray_darthomo, (blurparam[camera][0],blurparam[camera][1]), blurparam[camera][2])
    # cv.imshow("blur", blur)
    # cv.waitKey(0)
    circles = cv.HoughCircles(blur,cv.HOUGH_GRADIENT, dp=houghparam[camera][0], minDist=houghparam[camera][1], param1=houghparam[camera][2], param2=houghparam[camera][3], minRadius=houghparam[camera][4], maxRadius=houghparam[camera][5])

    if circles is not None:
        circles = np.round(circles[0,:]).astype("int")
        circleslist.append(circles)
        
        for (x,y,r) in circles:
            cv.circle(darthomo, (x,y), 1, (255,0,0), 2)
            cv.circle(darthomo, (x,y), 14, (255,0,0), 1) # -- za 14 i 31 vrijedi centercir = [(474, 476), (478, 476), (470, 476)] - x,y srediste ploce - 1.01, 1.038, 1.05
            cv.circle(darthomo, (x,y), 32, (255,0,0), 1)
            cv.circle(darthomo, (x,y), 191, (255,0,0), 1) # -- za 190 i 210 vrijedi centercir = [(474, 476), (478, 478), (472, 476)] - x,y srediste ploce - isto above
            cv.circle(darthomo, (x,y), 211, (255,0,0), 1)
            # cv.circle(darthomo, (x,y), 315, (255,0,0), 1)
            # cv.circle(darthomo, (x,y), 335, (255,0,0), 1) # -- za 316 i 336 vrijedi centercir = [(476, 476),(478, 480),(472, 478)] - x,y srediste ploce - 
            print(x,y)
    cv.imshow("detectedcircle", darthomo)
    cv.waitKey(0)
    cv.destroyAllWindows()



